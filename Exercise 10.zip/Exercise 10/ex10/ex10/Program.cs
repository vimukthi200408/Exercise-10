﻿namespace ex10
{
    class Program
    {
       
       
        
        static void Main(string[] args)
        {
            runMenu();

        }

        
        static void runMenu()
        {
            
            int[,] progressData = new int[10, 100];//the array to store after reading the results file
            string table = " ";// to store the display output
            int option;
            Boolean pass = false, pass2 = false;

            for (int i = 1; i >= 1; i++)//the menu
            {



                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                Console.WriteLine("        The Progress Statistics Generator             ");

                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("[1] End Testing the program");
                Console.WriteLine("[2] Display 'About' Information");
                Console.WriteLine("[3] Read and store data from files");
                Console.WriteLine("[4] Generate a Results Data Table");
                Console.WriteLine("[5] Save Results Statistics to a file");
                Console.WriteLine("[6] Display Results Statistics from a file");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.Write("Which option would you like (1-6): ");

                option = Convert.ToInt32(Console.ReadLine());//geting option from user
                Console.WriteLine("\n\n");

                switch (option)
                {
                    case 1:

                        Console.WriteLine("\nThank you for tesitng this application.");
                        
                        Environment.Exit(0);//exiting the application
                        
                        break;

                    case 2:

                        displayText("About.txt");

                        Console.ReadKey();
                        break;

                    case 3:

                        Console.WriteLine("Data loading from Results.txt");

                        creatlist("Results.txt",progressData);

                        pass = true;//cant go to option 4 unless it goes through 3 first

                        break;

                    case 4:

                        if (pass == true)// checks if user has gone throughh option 3
                        {
                            pass2 = true;//cant go to option 5 unless it goes through 4 first
                            table = generateTable(progressData);
                            Console.WriteLine(table);
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("Please select option [3] to first load data ! ");
                        }
                        
                        break;

                    case 5:

                        if (pass == true && pass2==true)// checks if user has gone throughh option 3 and 4
                        {
                            saveData(table);
                        }
                        else
                        {
                            Console.WriteLine("Please select option [4] to first generate data ! ");
                        }


                        break;

                    case 6:

                        Console.WriteLine("\n       All saved Statistics       ");
                     
                        displayText("savedProgressData.txt");

                        Console.ReadKey();
                        break;

                    default:

                        Console.WriteLine("\nEntered option is not valid, Try Again");
                        break;
                }
                Console.WriteLine("\n\n\n\n");
            }

        }



        static void displayText(string filename)//function outputs (displays) text file
        {
            string readText = File.ReadAllText(filename); 
            Console.WriteLine(readText);  
        }



        static void creatlist(string filename, int[,] progressData)// reads Result.txt and stores in array
        {
            
            
            using (Stream stream = File.Open(filename, FileMode.Open))

            using (TextReader sr = new StreamReader(stream))
            {
                string line;
                int i = 0, j = 0;
                while ((line = sr.ReadLine()) != null)
                {
                    
                    string[] arr = line.Trim().Split();
                    foreach (var item in arr)
                    {


                        progressData[i, j] = Convert.ToInt32(item);
                        i++;

                        if (i > 9)
                        {                       
                            i =0;
                            j++;
                        }
                        
                        
                    }
                }

               

            }
          
        }



        static string generateTable(int[,] progressData)// calculates and returns a string to display (the statistics)
        {
            string text;
            int stunum;
            int mark;
            int higherdistinction = 0, distinction = 0, creditpass =0, pass =0, fail =0;

            Random random = new Random();
            int randumnum = random.Next(0, 9);

            do//user input should be between (1-100)
            {
                Console.Write("How many students in class ? (1-100) ");
                stunum = Convert.ToInt32(Console.ReadLine());

            } while (stunum > 100 || stunum < 1);
            

            

            Console.WriteLine("\nAssessment "+(randumnum+1)+" has been selected randomly\n");


            for(int i = 0; i < stunum; i++)//checks which catagory the marks fall into and keeps a count
            {
                mark = progressData[randumnum, i];

                if (mark <= 49)
                {
                    fail++;
                }
                else if (mark <= 59)
                {
                    pass++;
                }
                else if (mark <= 69)
                {
                    creditpass++;
                }
                else if (mark <= 79)
                {
                    distinction++;
                }
                else if (mark <= 100)
                {
                    higherdistinction++;
                }

            }

            text = "You have entered " + stunum + " students." +
                "\nAssessment " + (randumnum+1) + " has been selected randomly" +
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" +
                "\nHD : " + stars(higherdistinction) +
                "\nD  : " + stars(distinction) +
                "\nCR : " + stars(creditpass) +
                "\nP  : " + stars(pass) +
                "\nF  : " + stars(fail) ;

            return text;
        }



        static string stars(int num)// returns a number of stars for the statistics
        {
            String s = "";
            
            for (int i = 0;i<num;i++)
            {
                s = s + '*';
            }
            return s;

        }



        static void saveData(string table)//saves the statistics to a text file savedProgressData.txt
        {
            char option;

            Console.WriteLine(table);
            Console.Write("  \nDo you want to save this data? (y/n) : ");

            option = Convert.ToChar(Console.ReadLine());

            switch (option)
            {
                case 'y':

                    TextWriter tsw = new StreamWriter(@"savedProgressData.txt", true);
                    tsw.WriteLine("\n\n"+table);
                    tsw.Close();                 
                    Console.WriteLine("\nThe data has been saved succesfully");

                    break;

                case 'n':

                    break;

                default:

                    Console.WriteLine("\nInvalid input, Try Again");

                    break;

            }
               
        }

    }
}